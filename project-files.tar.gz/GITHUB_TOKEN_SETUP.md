# 🔑 GitHub Token Setup - Fix Push Issue

## The Problem
Your current token doesn't have push permissions to the repository.

## ✅ Solution (5 minutes)

### Step 1: Create New Token with Correct Permissions

1. **Go to GitHub Token Settings:**
   ```
   https://github.com/settings/tokens/new
   ```

2. **Configure Token:**
   - **Note:** `IntelliDoc-AI-Push-Token`
   - **Expiration:** 90 days
   - **Select Scopes:** ✅ Check these boxes:
     - ✅ `repo` (Full control of private repositories)
       - ✅ `repo:status`
       - ✅ `repo_deployment`
       - ✅ `public_repo`
       - ✅ `repo:invite`
       - ✅ `security_events`
     - ✅ `workflow` (Update GitHub Action workflows)
     - ✅ `write:packages` (Upload packages)
     - ✅ `delete:packages` (Delete packages)

3. **Generate Token:**
   - Click "Generate token"
   - **COPY THE TOKEN IMMEDIATELY** (you won't see it again!)

### Step 2: Push Code with New Token

Once you have the new token, run these commands:

```bash
# Navigate to project
cd "/Users/ritikraushan/Automated Invoice Intelligence Engine"

# Set the new token (replace YOUR_NEW_TOKEN with actual token)
git remote set-url origin https://ritikravi:YOUR_NEW_TOKEN@github.com/ritikravi/IntelliDoc-AI-.git

# Push the code
git push -u origin main --force
```

### Step 3: Verify Push

```bash
# Check if push succeeded
git log --oneline -1

# Verify on GitHub
open https://github.com/ritikravi/IntelliDoc-AI-
```

---

## 🚀 Quick Commands (Copy-Paste After Getting Token)

```bash
# Replace YOUR_NEW_TOKEN_HERE with your actual token
export GITHUB_TOKEN="YOUR_NEW_TOKEN_HERE"

# Push with new token
git remote set-url origin https://ritikravi:${GITHUB_TOKEN}@github.com/ritikravi/IntelliDoc-AI-.git
git push -u origin main --force

# Verify
echo "✅ Check your repo: https://github.com/ritikravi/IntelliDoc-AI-"
```

---

## 📋 What Happens Next

Once pushed successfully:

1. ✅ Code will be on GitHub
2. ✅ Deploy Backend to Render (from GitHub)
3. ✅ Deploy AI Service to Render (from GitHub)
4. ✅ Update Frontend with backend URLs
5. ✅ Project fully deployed!

---

## 🎯 Alternative: Use GitHub Desktop (Easiest!)

If you prefer a GUI:

1. Download GitHub Desktop: https://desktop.github.com/
2. Sign in with your GitHub account (ritikravi)
3. Add this repository
4. Click "Push origin"
5. Done! ✅

---

## 💡 Why This Happened

Your previous token had limited permissions. The new token with `repo` scope will have full push access.

---

**Next:** Get your new token and run the commands above! 🚀
